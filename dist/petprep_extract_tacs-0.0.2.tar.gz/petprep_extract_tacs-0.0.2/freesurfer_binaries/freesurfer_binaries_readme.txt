contents of this folder are ignored as they are compressed FreeSurfer images/binaries, this file exists to 
keep this folder in version control.